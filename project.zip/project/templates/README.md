Files in this folder should be automatically created by Pagedraw. `application.py` can then render them
by calling `render_template('foo.py')`
